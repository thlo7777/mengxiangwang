jQuery(function($){
  $(document).ready(function() {
    // initialise Superfish
    $('#main-menu ul').superfish({
        animation: {height:'show'}
    });
  });
});
