<?php 

require_once(drupal_get_path('theme', 'dynamik').'/includes/header.php');
require_once(drupal_get_path('theme', 'dynamik').'/includes/front-page.php');
require_once(drupal_get_path('theme', 'dynamik').'/includes/footer.php');
	
?>