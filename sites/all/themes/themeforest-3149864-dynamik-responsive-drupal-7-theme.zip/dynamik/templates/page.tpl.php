<?php 

dynamik_header($page);

include(drupal_get_path('theme', 'dynamik').'/includes/page.php'); 

dynamik_footer($page);

?>